package com.trevorwiebe.ynab.connections;

public class FetchBudgets {
}
